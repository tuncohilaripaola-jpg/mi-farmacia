<?php

function esAdministrador()
{
    return isset($_SESSION['rol']) &&
           $_SESSION['rol'] == 'Administrador';
}

function esVendedor()
{
    return isset($_SESSION['rol']) &&
           $_SESSION['rol'] == 'Vendedor';
}

function soloAdministrador()
{
    if (!esAdministrador()) {

        header("Location: /FARMACIA_20/index.php");

        exit();

    }
}

?>