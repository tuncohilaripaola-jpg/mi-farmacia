<?php

include("conexion.php");

echo "<h1>CONEXIÓN EXITOSA</h1>";
echo "<p>La base de datos FARMACIA_20 está conectada correctamente.</p>";

?>