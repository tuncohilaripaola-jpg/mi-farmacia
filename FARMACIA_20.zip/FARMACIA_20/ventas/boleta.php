<?php

include("../seguridad.php");
include("../conexion.php");

if (!isset($_GET["id"])) {
    die("Boleta no encontrada.");
}

$idventa = intval($_GET["id"]);

$sql = $conexion->prepare("
SELECT
v.*,
CONCAT(c.nombres,' ',c.apellidos) AS cliente,
CONCAT(u.nombres,' ',u.apellidos) AS usuario
FROM ventas v
INNER JOIN clientes c ON v.idcliente = c.idcliente
INNER JOIN usuarios u ON v.idusuario = u.idusuario
WHERE v.idventa = ?
");

$sql->bind_param("i",$idventa);
$sql->execute();
$venta = $sql->get_result()->fetch_assoc();

if(!$venta){
    die("La venta no existe.");
}

$sqlDetalle = $conexion->prepare("
SELECT
d.*,
p.nombre_producto
FROM detalle_ventas d
INNER JOIN productos p
ON d.idproducto=p.idproducto
WHERE d.idventa=?
");

$sqlDetalle->bind_param("i",$idventa);
$sqlDetalle->execute();
$detalle = $sqlDetalle->get_result();

?>

<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">

<title>Boleta de Venta</title>

<style>

body{
font-family:Arial;
background:#ececec;
}

.boleta{

width:850px;
margin:25px auto;
background:#fff;
padding:25px;
border-radius:10px;
box-shadow:0px 0px 12px #999;

}

.encabezado{

text-align:center;
border-bottom:3px solid #28a745;
padding-bottom:10px;

}

.encabezado h1{

margin:0;
color:#28a745;

}

.encabezado h2{

margin:5px;
color:#444;

}

table{

width:100%;
border-collapse:collapse;
margin-top:20px;

}

table th{

background:#28a745;
color:white;
padding:10px;

}

table td{

padding:8px;
border:1px solid #ddd;

}

.totales{

width:300px;
float:right;
margin-top:20px;

}

.totales td{

padding:8px;

}

.total{

background:#28a745;
color:white;
font-size:18px;
font-weight:bold;

}

.footer{

margin-top:40px;
text-align:center;
font-size:14px;

}

.botones{

text-align:center;
margin-top:30px;

}

button{

padding:10px 20px;
margin:5px;
cursor:pointer;
font-size:15px;

}

@media print{

.botones{

display:none;

}

body{

background:white;

}

.boleta{

box-shadow:none;

width:100%;

}

}

</style>

</head>

<body>

<div class="boleta">

<div class="encabezado">

<h1>FARMACIA 20</h1>

<h2>BOLETA DE VENTA</h2>

<h3>B001-<?php echo str_pad($venta["idventa"],8,"0",STR_PAD_LEFT); ?></h3>

<p>

RUC: 20123456789<br>

Av. Ejército 123 - Arequipa<br>

Teléfono: (054) 123456

</p>

</div>

<br>

<table border="0">

<tr>

<td><b>Fecha:</b></td>

<td><?php echo date("d/m/Y",strtotime($venta["fecha"])); ?></td>

<td><b>Cliente:</b></td>

<td><?php echo $venta["cliente"]; ?></td>

</tr>

<tr>

<td><b>Vendedor:</b></td>

<td><?php echo $venta["usuario"]; ?></td>

<td><b>N° Venta:</b></td>

<td><?php echo $venta["idventa"]; ?></td>

</tr>

</table>

<table>

<tr>

<th>Producto</th>

<th>Cantidad</th>

<th>Precio</th>

<th>Importe</th>

</tr>

<?php while($fila=$detalle->fetch_assoc()){ ?>

<tr>

<td><?php echo $fila["nombre_producto"]; ?></td>

<td align="center"><?php echo $fila["cantidad"]; ?></td>

<td align="right">S/. <?php echo number_format($fila["precio_unitario"],2); ?></td>

<td align="right">S/. <?php echo number_format($fila["importe"],2); ?></td>

</tr>

<?php } ?>

</table>

<table class="totales">

<tr>

<td>Subtotal</td>

<td align="right">S/. <?php echo number_format($venta["subtotal"],2); ?></td>

</tr>

<tr>

<td>IGV (18%)</td>

<td align="right">S/. <?php echo number_format($venta["igv"],2); ?></td>

</tr>

<tr class="total">

<td>TOTAL</td>

<td align="right">S/. <?php echo number_format($venta["total"],2); ?></td>

</tr>

</table>

<div style="clear:both;"></div>

<div class="footer">

<hr>

<b>Representación impresa de la Boleta de Venta</b>

<br><br>

Gracias por su compra.

<br>

Vuelva pronto.

</div>

<div class="botones">

<button onclick="window.print()">

🖨 Imprimir

</button>

<button onclick="location.href='registrar.php'">

Nueva Venta

</button>

<button onclick="location.href='../index.php'">

Menú Principal

</button>

</div>

</div>

</body>

</html>

<?php

$sql->close();
$sqlDetalle->close();
$conexion->close();

?>