<?php

include("../seguridad.php");

include("../roles.php");


?>
<?php

include("../conexion.php");

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $idcliente = $_POST['idcliente'];
    $idusuario = $_POST['idusuario'];
    $idcondicion = $_POST['idcondicion'];
    $idproducto = $_POST['idproducto'];
    $cantidad = $_POST['cantidad'];

    // Obtener precio y stock del producto
    $sql_producto = "SELECT precio_venta, stock
                     FROM productos
                     WHERE idproducto = $idproducto";

    $resultado_producto = $conexion->query($sql_producto);

    $producto = $resultado_producto->fetch_assoc();

    $precio_unitario = $producto['precio_venta'];
    $stock_actual = $producto['stock'];

    if ($cantidad > $stock_actual) {

        $mensaje = " No hay suficiente stock disponible.";

    } else {

        // Calcular importes
        $subtotal = $precio_unitario * $cantidad;

        $igv = $subtotal * 0.18;

        $total = $subtotal + $igv;


        // Insertar venta
        $sql_venta = "INSERT INTO ventas
                      (
                          idcliente,
                          idusuario,
                          idcondicion,
                          subtotal,
                          igv,
                          total
                      )
                      VALUES
                      (
                          '$idcliente',
                          '$idusuario',
                          '$idcondicion',
                          '$subtotal',
                          '$igv',
                          '$total'
                      )";

        if ($conexion->query($sql_venta) === TRUE) {

            $idventa = $conexion->insert_id;


            // Insertar detalle
            $importe = $precio_unitario * $cantidad;

            $sql_detalle = "INSERT INTO detalle_ventas
                            (
                                idventa,
                                idproducto,
                                cantidad,
                                precio_unitario,
                                importe
                            )
                            VALUES
                            (
                                '$idventa',
                                '$idproducto',
                                '$cantidad',
                                '$precio_unitario',
                                '$importe'
                            )";

            $conexion->query($sql_detalle);


            // Actualizar stock
            $sql_stock = "UPDATE productos
                          SET stock = stock - $cantidad
                          WHERE idproducto = $idproducto";

            $conexion->query($sql_stock);


            echo "<script>
            alert('Venta registrada correctamente');
            window.location='boleta.php?id=".$idventa."';
            </script>";
            exit();

        } else {

            $mensaje = " Error: " . $conexion->error;

        }

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Registrar Boleta de Venta</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>🧾 Registrar Boleta de Venta</h1>

    <?php if ($mensaje != "") { ?>

        <p>

            <?php echo $mensaje; ?>

        </p>

    <?php } ?>


    <form method="POST">

        <label>Cliente:</label>
        <br>

        <select name="idcliente" required>

            <?php

            $clientes = $conexion->query(
                "SELECT * FROM clientes
                 WHERE estado = 'A'"
            );

            while ($cliente = $clientes->fetch_assoc()) {

            ?>

                <option value="<?php echo $cliente['idcliente']; ?>">

                    <?php

                    echo $cliente['nombres']
                         . " "
                         . $cliente['apellidos'];

                    ?>

                </option>

            <?php } ?>

        </select>

        <br><br>


        <label>Vendedor:</label>
        <br>

        <select name="idusuario" required>

            <?php

            $usuarios = $conexion->query(
                "SELECT * FROM usuarios
                 WHERE estado = 'A'"
            );

            while ($usuario = $usuarios->fetch_assoc()) {

            ?>

                <option value="<?php echo $usuario['idusuario']; ?>">

                    <?php echo $usuario['usuario']; ?>

                </option>

            <?php } ?>

        </select>

        <br><br>


        <label>Condición de Venta:</label>
        <br>

        <select name="idcondicion" required>

            <?php

            $condiciones = $conexion->query(
                "SELECT * FROM condiciones_venta"
            );

            while ($condicion = $condiciones->fetch_assoc()) {

            ?>

                <option value="<?php echo $condicion['idcondicion']; ?>">

                    <?php echo $condicion['nombre_condicion']; ?>

                </option>

            <?php } ?>

        </select>

        <br><br>


        <label>Producto:</label>
        <br>

        <select name="idproducto" required>

            <?php

            $productos = $conexion->query(
                "SELECT * FROM productos
                 WHERE estado = 'A'
                 AND stock > 0"
            );

            while ($producto = $productos->fetch_assoc()) {

            ?>

                <option value="<?php echo $producto['idproducto']; ?>">

                    <?php

                    echo $producto['nombre_producto']
                         . " - S/ "
                         . $producto['precio_venta']
                         . " - Stock: "
                         . $producto['stock'];

                    ?>

                </option>

            <?php } ?>

        </select>

        <br><br>


        <label>Cantidad:</label>
        <br>

        <input
            type="number"
            name="cantidad"
            min="1"
            required
        >

        <br><br>


        <button type="submit">

            💾 Registrar Venta

        </button>

    </form>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>