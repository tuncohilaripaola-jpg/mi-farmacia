<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$sql = "SELECT * FROM proveedores";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Proveedores - Farmacia 20</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>🏢 Lista de Proveedores</h1>

    <a href="agregar.php">
        ➕ Agregar Proveedor
    </a>

    <br><br>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>ID</th>
            <th>RUC</th>
            <th>Nombre</th>
            <th>Dirección</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Estado</th>
            <th>Acciones</th>

        </tr>

        <?php while ($proveedor = $resultado->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $proveedor['idproveedor']; ?>
            </td>

            <td>
                <?php echo $proveedor['ruc']; ?>
            </td>

            <td>
                <?php echo $proveedor['nombre_proveedor']; ?>
            </td>

            <td>
                <?php echo $proveedor['direccion']; ?>
            </td>

            <td>
                <?php echo $proveedor['telefono']; ?>
            </td>

            <td>
                <?php echo $proveedor['email']; ?>
            </td>

            <td>
                <?php echo $proveedor['estado']; ?>
            </td>

            <td>

                <a href="editar.php?id=<?php echo $proveedor['idproveedor']; ?>">
                    ✏️ Editar
                </a>

                |

                <a
                    href="eliminar.php?id=<?php echo $proveedor['idproveedor']; ?>"
                    onclick="return confirm('¿Deseas eliminar este proveedor?')"
                >
                    🗑️ Eliminar
                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">
        ⬅️ Volver al menú
    </a>

</div>

</body>

</html>