<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>
<?php

include("../conexion.php");

$id = $_GET['id'];

$sql = "SELECT * FROM proveedores
        WHERE idproveedor = $id";

$resultado = $conexion->query($sql);

$proveedor = $resultado->fetch_assoc();


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $ruc = $_POST['ruc'];
    $nombre_proveedor = $_POST['nombre_proveedor'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $estado = $_POST['estado'];

    $sql = "UPDATE proveedores SET

            ruc = '$ruc',
            nombre_proveedor = '$nombre_proveedor',
            direccion = '$direccion',
            telefono = '$telefono',
            email = '$email',
            estado = '$estado'

            WHERE idproveedor = $id";


    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Editar Proveedor</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>✏️ Editar Proveedor</h1>

    <form method="POST">

        <label>RUC:</label>
        <br>

        <input
            type="text"
            name="ruc"
            value="<?php echo $proveedor['ruc']; ?>"
            maxlength="11"
            required
        >

        <br><br>

        <label>Nombre del Proveedor:</label>
        <br>

        <input
            type="text"
            name="nombre_proveedor"
            value="<?php echo $proveedor['nombre_proveedor']; ?>"
            required
        >

        <br><br>

        <label>Dirección:</label>
        <br>

        <input
            type="text"
            name="direccion"
            value="<?php echo $proveedor['direccion']; ?>"
        >

        <br><br>

        <label>Teléfono:</label>
        <br>

        <input
            type="text"
            name="telefono"
            value="<?php echo $proveedor['telefono']; ?>"
        >

        <br><br>

        <label>Email:</label>
        <br>

        <input
            type="email"
            name="email"
            value="<?php echo $proveedor['email']; ?>"
        >

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option
                value="A"
                <?php
                if ($proveedor['estado'] == 'A')
                    echo "selected";
                ?>
            >
                ACTIVO
            </option>

            <option
                value="I"
                <?php
                if ($proveedor['estado'] == 'I')
                    echo "selected";
                ?>
            >
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">

            💾 Actualizar Proveedor

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Proveedores

    </a>

</div>

</body>

</html>