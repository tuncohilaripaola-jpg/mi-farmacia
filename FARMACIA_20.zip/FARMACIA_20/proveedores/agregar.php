<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $ruc = $_POST['ruc'];
    $nombre_proveedor = $_POST['nombre_proveedor'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO proveedores
            (
                ruc,
                nombre_proveedor,
                direccion,
                telefono,
                email,
                estado
            )
            VALUES
            (
                '$ruc',
                '$nombre_proveedor',
                '$direccion',
                '$telefono',
                '$email',
                '$estado'
            )";

    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Agregar Proveedor</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>➕ Agregar Proveedor</h1>

    <form method="POST">

        <label>RUC:</label>
        <br>

        <input
            type="text"
            name="ruc"
            maxlength="11"
            required
        >

        <br><br>

        <label>Nombre del Proveedor:</label>
        <br>

        <input
            type="text"
            name="nombre_proveedor"
            required
        >

        <br><br>

        <label>Dirección:</label>
        <br>

        <input
            type="text"
            name="direccion"
        >

        <br><br>

        <label>Teléfono:</label>
        <br>

        <input
            type="text"
            name="telefono"
        >

        <br><br>

        <label>Email:</label>
        <br>

        <input
            type="email"
            name="email"
        >

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A">
                ACTIVO
            </option>

            <option value="I">
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">

            💾 Guardar Proveedor

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Proveedores

    </a>

</div>

</body>

</html>