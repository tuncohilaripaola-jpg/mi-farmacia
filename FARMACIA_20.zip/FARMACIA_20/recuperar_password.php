<?php
session_start();
include("conexion.php");

$mensaje="";

if(isset($_POST["cambiar"])){

    $usuario = trim($_POST["usuario"]);
    $nueva   = trim($_POST["nueva"]);
    $confirmar = trim($_POST["confirmar"]);

    if($nueva != $confirmar){

        $mensaje = "Las contraseñas no coinciden.";

    }else{

        // Verificar si existe el usuario
        $sql = "SELECT * FROM usuarios WHERE usuario='$usuario'";
        $resultado = $conexion->query($sql);

        if($resultado->num_rows > 0){

            // Actualizar contraseña
            $sql2 = "UPDATE usuarios
                     SET password='$nueva'
                     WHERE usuario='$usuario'";

            if($conexion->query($sql2)){

                echo "<script>
                        alert('Contraseña actualizada correctamente');
                        window.location='login.php';
                      </script>";
                exit();

            }else{

                $mensaje="Error al actualizar la contraseña.";

            }

        }else{

            $mensaje="El usuario no existe.";

        }

    }

}
?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Recuperar Contraseña</title>

<link rel="stylesheet" href="css/estilos.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>

<body class="login-body">

<div class="login-card">

<div class="login-logo">
🔑
</div>

<h1>Recuperar Contraseña</h1>

<p class="login-subtitulo">
Cambiar contraseña del usuario
</p>

<?php
if($mensaje!=""){
?>

<div class="login-error">
<i class="fa-solid fa-circle-exclamation"></i>
<?php echo $mensaje; ?>
</div>

<?php } ?>

<form method="POST">

<div class="campo">

<label>
<i class="fa-solid fa-user"></i>
Usuario
</label>

<input
type="text"
name="usuario"
required>

</div>

<div class="campo">

<label>
<i class="fa-solid fa-lock"></i>
Nueva contraseña
</label>

<input
type="password"
name="nueva"
required>

</div>

<div class="campo">

<label>
<i class="fa-solid fa-lock"></i>
Confirmar contraseña
</label>

<input
type="password"
name="confirmar"
required>

</div>

<button
type="submit"
name="cambiar"
class="btn-login">

<i class="fa-solid fa-key"></i>

Cambiar Contraseña

</button>

</form>

<br>

<a
href="login.php"
class="btn-login"
style="display:block;text-align:center;text-decoration:none;">

<i class="fa-solid fa-arrow-left"></i>

Volver al Login

</a>

</div>

</body>

</html>