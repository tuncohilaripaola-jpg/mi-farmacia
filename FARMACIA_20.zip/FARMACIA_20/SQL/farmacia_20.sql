-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-07-2026 a las 20:37:48
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `farmacia_20`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `idcategoria` int(11) NOT NULL,
  `nombre_categoria` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `estado` char(1) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`idcategoria`, `nombre_categoria`, `descripcion`, `estado`) VALUES
(1, 'Analgésicos', 'Medicamentos para aliviar el dolor', 'A'),
(2, 'Antibióticos', 'Medicamentos para tratar infecciones', 'A'),
(3, 'Antigripales', 'Medicamentos para síntomas de gripe', 'A'),
(4, 'Vitaminas', 'Suplementos y vitaminas', 'A'),
(5, 'Cuidado Personal', 'Productos de higiene y cuidado personal', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `idcliente` int(11) NOT NULL,
  `dni` varchar(8) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `estado` char(1) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idcliente`, `dni`, `nombres`, `apellidos`, `telefono`, `email`, `direccion`, `estado`) VALUES
(1, '70000001', 'Juan', 'Pérez López', '987654321', 'juan@gmail.com', 'Av. Ejército 101', 'A'),
(2, '70000002', 'María', 'García Torres', '987654322', 'maria@gmail.com', 'Av. Lima 202', 'A'),
(3, '70000003', 'Carlos', 'Rodríguez Díaz', '987654323', 'carlos@gmail.com', 'Calle Mercaderes 303', 'A'),
(4, '70000004', 'Ana', 'Sánchez Flores', '987654324', 'ana@gmail.com', 'Av. Dolores 404', 'A'),
(5, '70000005', 'Luis', 'Mendoza Quispe', '987654325', 'luis@gmail.com', 'Calle San Juan 505', 'A'),
(6, '70000006', 'Rosa', 'Fernández Soto', '987654326', 'rosa@gmail.com', 'Av. Parra 606', 'A'),
(7, '70000007', 'Pedro', 'Vargas Rojas', '987654327', 'pedro@gmail.com', 'Calle Sucre 707', 'A'),
(8, '70000008', 'Lucía', 'Torres Medina', '987654328', 'lucia@gmail.com', 'Av. Independencia 808', 'A'),
(9, '70000009', 'Miguel', 'Castro León', '987654329', 'miguel@gmail.com', 'Calle Jerusalén 909', 'A'),
(10, '70000010', 'Sofía', 'Ramírez Peña', '987654330', 'sofia@gmail.com', 'Av. Venezuela 1010', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `condiciones_venta`
--

CREATE TABLE `condiciones_venta` (
  `idcondicion` int(11) NOT NULL,
  `nombre_condicion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `condiciones_venta`
--

INSERT INTO `condiciones_venta` (`idcondicion`, `nombre_condicion`) VALUES
(1, 'Contado'),
(2, 'Crédito');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ventas`
--

CREATE TABLE `detalle_ventas` (
  `iddetalle` int(11) NOT NULL,
  `idventa` int(11) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `importe` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_ventas`
--

INSERT INTO `detalle_ventas` (`iddetalle`, `idventa`, `idproducto`, `cantidad`, `precio_unitario`, `importe`) VALUES
(1, 1, 1, 1, 0.50, 0.50),
(2, 2, 1, 2, 0.50, 1.00),
(3, 3, 9, 2, 3.00, 6.00),
(4, 4, 1, 5, 0.50, 2.50),
(5, 5, 1, 7, 0.50, 3.50),
(6, 6, 1, 2, 0.50, 1.00),
(7, 7, 1, 2, 0.50, 1.00),
(8, 8, 1, 5, 0.50, 2.50),
(9, 9, 1, 5, 0.50, 2.50),
(10, 10, 1, 10, 0.50, 5.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `idproducto` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre_producto` varchar(150) NOT NULL,
  `principio_activo` varchar(150) DEFAULT NULL,
  `presentacion` varchar(100) DEFAULT NULL,
  `concentracion` varchar(100) DEFAULT NULL,
  `idcategoria` int(11) NOT NULL,
  `idproveedor` int(11) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) NOT NULL DEFAULT 5,
  `precio_compra` decimal(10,2) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `estado` char(1) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`idproducto`, `codigo`, `nombre_producto`, `principio_activo`, `presentacion`, `concentracion`, `idcategoria`, `idproveedor`, `stock`, `stock_minimo`, `precio_compra`, `precio_venta`, `fecha_vencimiento`, `estado`) VALUES
(1, 'MED001', 'Paracetamol', 'Paracetamol', 'Tabletas', '500 mg', 1, 1, 61, 10, 0.20, 0.50, '2028-05-15', 'A'),
(2, 'MED002', 'Ibuprofeno', 'Ibuprofeno', 'Tabletas', '400 mg', 1, 2, 80, 10, 0.40, 0.90, '2027-11-20', 'A'),
(3, 'MED003', 'Amoxicilina', 'Amoxicilina', 'Cápsulas', '500 mg', 2, 3, 60, 10, 0.80, 1.50, '2027-08-10', 'A'),
(4, 'MED004', 'Azitromicina', 'Azitromicina', 'Tabletas', '500 mg', 2, 4, 40, 5, 2.50, 4.50, '2027-09-25', 'A'),
(5, 'MED005', 'Panadol Antigripal', 'Paracetamol + Fenilefrina', 'Tabletas', '500 mg', 3, 5, 70, 10, 0.60, 1.20, '2028-01-30', 'A'),
(6, 'MED006', 'Vitamina C', 'Ácido ascórbico', 'Tabletas', '1 g', 4, 6, 90, 10, 0.30, 0.80, '2028-06-12', 'A'),
(7, 'MED007', 'Multivitamínico', 'Vitaminas y minerales', 'Tabletas', 'Complejo', 4, 7, 50, 5, 5.00, 8.50, '2027-12-05', 'A'),
(8, 'MED008', 'Alcohol medicinal', 'Alcohol etílico', 'Frasco', '96°', 5, 8, 100, 15, 2.00, 4.00, '2029-02-15', 'A'),
(9, 'MED009', 'Jabón antibacterial', 'Triclosán', 'Unidad', '100 g', 5, 9, 73, 10, 1.50, 3.00, '2028-10-18', 'A'),
(10, 'MED010', 'Gel antibacterial', 'Alcohol etílico', 'Frasco', '70%', 5, 10, 65, 10, 3.00, 6.00, '2028-07-22', 'A'),
(11, 'MED011', 'Naproxeno', 'Naproxeno Sódico', 'Tabletas', '550 mg', 1, 1, 55, 10, 1.20, 1.80, '2028-09-15', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `idproveedor` int(11) NOT NULL,
  `ruc` varchar(11) NOT NULL,
  `nombre_proveedor` varchar(150) NOT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `estado` char(1) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`idproveedor`, `ruc`, `nombre_proveedor`, `direccion`, `telefono`, `email`, `estado`) VALUES
(1, '20100000001', 'Laboratorios FarmaPerú', 'Av. Industrial 101, Lima', '987111111', 'contacto@farmaperu.com', 'A'),
(2, '20100000002', 'Distribuidora Salud S.A.C.', 'Av. Arequipa 202, Lima', '987111112', 'ventas@salud.com', 'A'),
(3, '20100000003', 'Laboratorios Andinos', 'Av. Argentina 303, Lima', '987111113', 'ventas@andinos.com', 'A'),
(4, '20100000004', 'Farmacéutica Nacional', 'Av. Brasil 404, Lima', '987111114', 'contacto@farmnacional.com', 'A'),
(5, '20100000005', 'Importadora Médica Perú', 'Av. La Marina 505, Lima', '987111115', 'ventas@importmedica.com', 'A'),
(6, '20100000006', 'Productos Vitales S.A.C.', 'Av. Javier Prado 606, Lima', '987111116', 'info@vitales.com', 'A'),
(7, '20100000007', 'Distribuciones Médicas Sur', 'Av. Angamos 707, Lima', '987111117', 'ventas@medicasur.com', 'A'),
(8, '20100000008', 'Laboratorios Vida', 'Av. Colonial 808, Lima', '987111118', 'contacto@laboratoriosvida.com', 'A'),
(9, '20100000009', 'Comercial Farmacéutica', 'Av. Canadá 909, Lima', '987111119', 'ventas@comercialfarma.com', 'A'),
(10, '20100000010', 'Grupo Salud Perú', 'Av. Universitaria 1010, Lima', '987111120', 'contacto@gruposalud.com', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `rol` varchar(30) NOT NULL,
  `estado` char(1) DEFAULT 'A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `usuario`, `password`, `nombres`, `apellidos`, `rol`, `estado`) VALUES
(1, 'admin', '1234', 'Esteban', 'Torres Enriquez', 'Administrador', 'A'),
(2, 'vendedor1', '123456', 'Paola Brigitte', 'Tunco Hilari', 'Vendedor', 'A'),
(3, 'vendedor2', '123456', 'Paula Sarela', 'Carhuas Cutipa', 'Vendedor', 'A'),
(5, 'admin2', '1234', 'Raul Andres ', 'Yapo Coaquira', 'Administrador', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `idventa` int(11) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `idcliente` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idcondicion` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `igv` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`idventa`, `fecha`, `idcliente`, `idusuario`, `idcondicion`, `subtotal`, `igv`, `total`) VALUES
(1, '2026-07-20 03:34:28', 1, 1, 1, 0.50, 0.09, 0.59),
(2, '2026-07-20 03:43:38', 1, 1, 1, 1.00, 0.18, 1.18),
(3, '2026-07-20 03:44:13', 2, 5, 1, 6.00, 1.08, 7.08),
(4, '2026-07-20 03:53:54', 1, 5, 1, 2.50, 0.45, 2.95),
(5, '2026-07-20 03:54:03', 1, 1, 1, 3.50, 0.63, 4.13),
(6, '2026-07-20 08:29:55', 1, 1, 1, 1.00, 0.18, 1.18),
(7, '2026-07-20 08:43:06', 1, 1, 1, 1.00, 0.18, 1.18),
(8, '2026-07-20 08:43:45', 1, 5, 1, 2.50, 0.45, 2.95),
(9, '2026-07-20 11:05:08', 1, 1, 1, 2.50, 0.45, 2.95),
(10, '2026-07-20 11:32:49', 1, 1, 1, 5.00, 0.90, 5.90);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`idcategoria`),
  ADD UNIQUE KEY `nombre_categoria` (`nombre_categoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idcliente`),
  ADD UNIQUE KEY `dni` (`dni`);

--
-- Indices de la tabla `condiciones_venta`
--
ALTER TABLE `condiciones_venta`
  ADD PRIMARY KEY (`idcondicion`);

--
-- Indices de la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD PRIMARY KEY (`iddetalle`),
  ADD KEY `fk_detalle_venta` (`idventa`),
  ADD KEY `fk_detalle_producto` (`idproducto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`idproducto`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `fk_producto_categoria` (`idcategoria`),
  ADD KEY `fk_producto_proveedor` (`idproveedor`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`idproveedor`),
  ADD UNIQUE KEY `ruc` (`ruc`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuario`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`idventa`),
  ADD KEY `fk_venta_cliente` (`idcliente`),
  ADD KEY `fk_venta_usuario` (`idusuario`),
  ADD KEY `fk_venta_condicion` (`idcondicion`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `idcategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `condiciones_venta`
--
ALTER TABLE `condiciones_venta`
  MODIFY `idcondicion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  MODIFY `iddetalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `idproducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `idproveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `idventa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`idproducto`) REFERENCES `productos` (`idproducto`),
  ADD CONSTRAINT `fk_detalle_venta` FOREIGN KEY (`idventa`) REFERENCES `ventas` (`idventa`) ON DELETE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`idcategoria`) REFERENCES `categorias` (`idcategoria`),
  ADD CONSTRAINT `fk_producto_proveedor` FOREIGN KEY (`idproveedor`) REFERENCES `proveedores` (`idproveedor`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_venta_cliente` FOREIGN KEY (`idcliente`) REFERENCES `clientes` (`idcliente`),
  ADD CONSTRAINT `fk_venta_condicion` FOREIGN KEY (`idcondicion`) REFERENCES `condiciones_venta` (`idcondicion`),
  ADD CONSTRAINT `fk_venta_usuario` FOREIGN KEY (`idusuario`) REFERENCES `usuarios` (`idusuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
