<?php

session_start();

if (!isset($_SESSION['idusuario'])) {

    header("Location: login.php");

    exit();

}

include("roles.php");

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Farmacia 20</title>

    <link rel="stylesheet" href="css/estilos.css">

</head>

<body>

<div class="contenedor">

    <header>

        <h1>💊 FARMACIA 20</h1>

        <p>Sistema de Facturación y Control de Stocks</p>

        <p>

            👤 Usuario:
            <?php echo $_SESSION['usuario']; ?>

            |

            Rol:
            <?php echo $_SESSION['rol']; ?>

        </p>

        <a href="cerrar_sesion.php">

            🚪 Cerrar Sesión

        </a>

    </header>


    <main class="menu">


        <!-- ARCHIVOS -->

        <section class="modulo">

            <h2>📁 ARCHIVOS</h2>


            <!-- ADMINISTRADOR Y VENDEDOR -->

            <a href="clientes/listar.php">

                👥 Clientes

            </a>


            <!-- SOLO ADMINISTRADOR -->

            <?php if (esAdministrador()) { ?>

                <a href="productos/listar.php">

                    💊 Productos

                </a>


                <a href="proveedores/listar.php">

                    🏢 Proveedores

                </a>


                <a href="categorias/listar.php">

                    🗂️ Categorías

                </a>


                <a href="usuarios/listar.php">

                    👤 Usuarios

                </a>

            <?php } ?>

        </section>


        <!-- PROCESOS -->

        <section class="modulo">

            <h2>⚙️ PROCESOS</h2>

            <a href="ventas/registrar.php">

                🧾 Registrar Venta

            </a>

        </section>


        <!-- CONSULTAS -->

        <section class="modulo">

            <h2>🔍 CONSULTAS</h2>


            <a href="consultas/stock.php">

                📦 Stock de Productos

            </a>


            <a href="consultas/ventas_dia.php">

                📅 Ventas del Día

            </a>


            <a href="consultas/ventas_fecha.php">

                📆 Ventas por Fecha

            </a>


            <a href="consultas/ventas_cliente.php">

                👥 Ventas por Cliente

            </a>


            <a href="consultas/ventas_producto.php">

                💊 Ventas por Producto

            </a>


            <a href="consultas/ranking.php">

                🏆 Ranking de Ventas

            </a>

        </section>


        <!-- HERRAMIENTAS -->

        <?php if (esAdministrador()) { ?>

            <section class="modulo">

                <h2>🔐 HERRAMIENTAS</h2>


                <a href="usuarios/cambiar_password.php">

                    🔑 Cambiar Contraseña

                </a>

            </section>

        <?php } ?>


    </main>

</div>

</body>

</html>