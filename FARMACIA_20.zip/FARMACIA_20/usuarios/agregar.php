<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $rol = $_POST['rol'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO usuarios
            (
                usuario,
                password,
                nombres,
                apellidos,
                rol,
                estado
            )
            VALUES
            (
                '$usuario',
                '$password',
                '$nombres',
                '$apellidos',
                '$rol',
                '$estado'
            )";

    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Agregar Usuario</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>➕ Agregar Usuario</h1>

    <form method="POST">

        <label>Usuario:</label>
        <br>

        <input
            type="text"
            name="usuario"
            required
        >

        <br><br>

        <label>Contraseña:</label>
        <br>

        <input
            type="password"
            name="password"
            required
        >

        <br><br>

        <label>Nombres:</label>
        <br>

        <input
            type="text"
            name="nombres"
            required
        >

        <br><br>

        <label>Apellidos:</label>
        <br>

        <input
            type="text"
            name="apellidos"
            required
        >

        <br><br>

        <label>Rol:</label>
        <br>

        <select name="rol">

            <option value="Administrador">
                Administrador
            </option>

            <option value="Vendedor">
                Vendedor
            </option>

        </select>

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A">
                ACTIVO
            </option>

            <option value="I">
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">

            💾 Guardar Usuario

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Usuarios

    </a>

</div>

</body>

</html>