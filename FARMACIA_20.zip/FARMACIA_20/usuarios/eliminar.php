<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$id = $_GET['id'];

$sql = "DELETE FROM usuarios
        WHERE idusuario = $id";

if ($conexion->query($sql) === TRUE) {

    header("Location: listar.php");

    exit();

} else {

    echo "Error al eliminar: " . $conexion->error;

}

?>