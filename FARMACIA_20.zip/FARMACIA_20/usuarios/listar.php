<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>


<?php

include("../conexion.php");

$sql = "SELECT * FROM usuarios";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Usuarios - Farmacia 20</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>👤 Lista de Usuarios</h1>

    <a href="agregar.php">
        ➕ Agregar Usuario
    </a>

    <br><br>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>ID</th>
            <th>Usuario</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>Rol</th>
            <th>Estado</th>
            <th>Acciones</th>

        </tr>

        <?php while ($usuario = $resultado->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $usuario['idusuario']; ?>
            </td>

            <td>
                <?php echo $usuario['usuario']; ?>
            </td>

            <td>
                <?php echo $usuario['nombres']; ?>
            </td>

            <td>
                <?php echo $usuario['apellidos']; ?>
            </td>

            <td>
                <?php echo $usuario['rol']; ?>
            </td>

            <td>
                <?php echo $usuario['estado']; ?>
            </td>

            <td>

                <a href="editar.php?id=<?php echo $usuario['idusuario']; ?>">
                    ✏️ Editar
                </a>

                |

                <a
                    href="eliminar.php?id=<?php echo $usuario['idusuario']; ?>"
                    onclick="return confirm('¿Deseas eliminar este usuario?')"
                >
                    🗑️ Eliminar
                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">
        ⬅️ Volver al menú
    </a>

</div>

</body>

</html>