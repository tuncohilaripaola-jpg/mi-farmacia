<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$id = $_GET['id'];

$sql = "SELECT * FROM usuarios
        WHERE idusuario = $id";

$resultado = $conexion->query($sql);

$usuario = $resultado->fetch_assoc();


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario_nombre = $_POST['usuario'];
    $password = $_POST['password'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $rol = $_POST['rol'];
    $estado = $_POST['estado'];

    $sql = "UPDATE usuarios SET

            usuario = '$usuario_nombre',
            password = '$password',
            nombres = '$nombres',
            apellidos = '$apellidos',
            rol = '$rol',
            estado = '$estado'

            WHERE idusuario = $id";

    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Editar Usuario</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>✏️ Editar Usuario</h1>

    <form method="POST">

        <label>Usuario:</label>
        <br>

        <input
            type="text"
            name="usuario"
            value="<?php echo $usuario['usuario']; ?>"
            required
        >

        <br><br>

        <label>Contraseña:</label>
        <br>

        <input
            type="text"
            name="password"
            value="<?php echo $usuario['password']; ?>"
            required
        >

        <br><br>

        <label>Nombres:</label>
        <br>

        <input
            type="text"
            name="nombres"
            value="<?php echo $usuario['nombres']; ?>"
            required
        >

        <br><br>

        <label>Apellidos:</label>
        <br>

        <input
            type="text"
            name="apellidos"
            value="<?php echo $usuario['apellidos']; ?>"
            required
        >

        <br><br>

        <label>Rol:</label>
        <br>

        <select name="rol">

            <option value="Administrador"
                <?php
                if ($usuario['rol'] == 'Administrador')
                    echo "selected";
                ?>
            >
                Administrador
            </option>

            <option value="Vendedor"
                <?php
                if ($usuario['rol'] == 'Vendedor')
                    echo "selected";
                ?>
            >
                Vendedor
            </option>

        </select>

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A"
                <?php
                if ($usuario['estado'] == 'A')
                    echo "selected";
                ?>
            >
                ACTIVO
            </option>

            <option value="I"
                <?php
                if ($usuario['estado'] == 'I')
                    echo "selected";
                ?>
            >
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">

            💾 Actualizar Usuario

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Usuarios

    </a>

</div>

</body>

</html>