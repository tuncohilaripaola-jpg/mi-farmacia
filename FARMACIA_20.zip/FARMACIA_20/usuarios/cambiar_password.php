<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $idusuario = $_POST['idusuario'];
    $nueva_password = $_POST['nueva_password'];

    $sql = "UPDATE usuarios
            SET password = '$nueva_password'
            WHERE idusuario = $idusuario";

    if ($conexion->query($sql) === TRUE) {

        $mensaje = "✅ Contraseña actualizada correctamente.";

    } else {

        $mensaje = "❌ Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Cambiar Contraseña</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>🔑 Cambiar Contraseña</h1>

    <?php if ($mensaje != "") { ?>

        <p>

            <?php echo $mensaje; ?>

        </p>

    <?php } ?>

    <form method="POST">

        <label>Seleccionar Usuario:</label>

        <br><br>

        <select name="idusuario" required>

            <?php

            $usuarios = $conexion->query(
                "SELECT * FROM usuarios
                 WHERE estado = 'A'"
            );

            while ($usuario = $usuarios->fetch_assoc()) {

            ?>

                <option value="<?php echo $usuario['idusuario']; ?>">

                    <?php echo $usuario['usuario']; ?>

                </option>

            <?php } ?>

        </select>

        <br><br>

        <label>Nueva Contraseña:</label>

        <br><br>

        <input
            type="password"
            name="nueva_password"
            required
        >

        <br><br>

        <button type="submit">

            🔑 Cambiar Contraseña

        </button>

    </form>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>