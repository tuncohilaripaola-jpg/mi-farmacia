<?php
/*=========================================================
    SISTEMA : FARMACIA 20
    ARCHIVO : login.php
    DESCRIPCIÓN:
    Permite iniciar sesión en el sistema validando
    el usuario y la contraseña registrados en la
    base de datos.
==========================================================*/

//=========================================================
// INICIAR SESIÓN
//=========================================================
session_start();

//=========================================================
// CONEXIÓN A LA BASE DE DATOS
//=========================================================
include("conexion.php");

//=========================================================
// VARIABLE PARA MENSAJES
//=========================================================
$mensaje = "";

//=========================================================
// VALIDAR SI SE ENVIÓ EL FORMULARIO
//=========================================================
if($_SERVER["REQUEST_METHOD"]=="POST"){

    // Obtener datos del formulario
    $usuario  = $_POST["usuario"];
    $password = $_POST["password"];

    // Consulta SQL
    $sql="SELECT * FROM usuarios
          WHERE usuario='$usuario'
          AND password='$password'
          AND estado='A'";

    // Ejecutar consulta
    $resultado=$conexion->query($sql);

    // Si existe el usuario
    if($resultado->num_rows==1){

        // Obtener datos
        $fila=$resultado->fetch_assoc();

        // Crear variables de sesión
        $_SESSION["idusuario"]=$fila["idusuario"];
        $_SESSION["usuario"]=$fila["usuario"];
        $_SESSION["nombres"]=$fila["nombres"];
        $_SESSION["rol"]=$fila["rol"];

        // Ir al menú principal
        header("Location:index.php");
        exit();

    }else{

        // Mostrar error
        $mensaje="Usuario o contraseña incorrectos.";

    }

}
?>

<!DOCTYPE html>
<html lang="es">

<head>

    <!-- Configuración -->
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <!-- Título -->
    <title>Login | Farmacia 20</title>

    <!-- Hoja de estilos -->
    <link rel="stylesheet" href="css/estilos.css">

    <!-- Font Awesome -->
    <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>

<body class="login-body">

<!--======================================================
                    TARJETA LOGIN
=======================================================-->

<div class="login-card">

    <!-- Logo -->
    <div class="login-logo">
        💊
    </div>

    <!-- Nombre del sistema -->
    <h1>FARMACIA 20</h1>

    <!-- Subtítulo -->
    <p class="login-subtitulo">
        Sistema de Gestión Farmacéutica
    </p>

    <!--==================================================
            MENSAJE DE ERROR
    ===================================================-->

    <?php if($mensaje!=""){ ?>

        <div class="login-error">

            <i class="fa-solid fa-circle-exclamation"></i>

            <?php echo $mensaje; ?>

        </div>

    <?php } ?>

    <!--==================================================
                    FORMULARIO
    ===================================================-->

    <form method="POST">

        <!--==============================
                USUARIO
        ==============================-->

        <div class="campo">

            <label>

                <i class="fa-solid fa-user"></i>

                Usuario

            </label>

            <input
                type="text"
                name="usuario"
                placeholder="Ingrese su usuario"
                required>

        </div>

        <!--==============================
                CONTRASEÑA
        ==============================-->

        <div class="campo">

            <label>

                <i class="fa-solid fa-lock"></i>

                Contraseña

            </label>

            <div class="campo-password">

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Ingrese su contraseña"
                    required>

                <!-- OJO -->
                <i class="fa-solid fa-eye"
                   id="togglePassword"></i>

            </div>

        </div>

        <!--==============================
            BOTÓN INICIAR SESIÓN
        ==============================-->

        <button
            type="submit"
            class="btn-login">

            <i class="fa-solid fa-right-to-bracket"></i>

            Iniciar Sesión

        </button>

    </form>

    <!--==================================================
        ENLACE RECUPERAR CONTRASEÑA
    ===================================================-->

    <p class="login-link">

        <a href="recuperar_password.php">

            <i class="fa-solid fa-key"></i>

            ¿Olvidó su contraseña?

        </a>

    </p>

    <!--==================================================
                PIE DEL LOGIN
    ===================================================-->

    <div class="login-footer">

        <i class="fa-solid fa-shield-halved"></i>

        Acceso seguro al sistema

    </div>

</div>

<!--======================================================
        JAVASCRIPT MOSTRAR CONTRASEÑA
=======================================================-->

<script>

// Obtener elementos
const togglePassword =
document.getElementById("togglePassword");

const password =
document.getElementById("password");

// Evento del ojito
togglePassword.addEventListener("click",function(){

    if(password.type==="password"){

        password.type="text";

        this.classList.remove("fa-eye");
        this.classList.add("fa-eye-slash");

    }else{

        password.type="password";

        this.classList.remove("fa-eye-slash");
        this.classList.add("fa-eye");

    }

});

</script>

</body>

</html>
```
