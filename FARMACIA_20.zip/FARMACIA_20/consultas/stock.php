<?php

include("../seguridad.php");

include("../roles.php");


?>

<?php

include("../conexion.php");

$sql = "SELECT
            p.codigo,
            p.nombre_producto,
            c.nombre_categoria,
            p.stock,
            p.stock_minimo,
            p.precio_venta,
            p.fecha_vencimiento
        FROM productos p
        INNER JOIN categorias c
            ON p.idcategoria = c.idcategoria
        ORDER BY p.stock ASC";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Stock de Productos</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>📦 Stock de Productos</h1>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>Código</th>
            <th>Producto</th>
            <th>Categoría</th>
            <th>Stock</th>
            <th>Stock Mínimo</th>
            <th>Precio Venta</th>
            <th>Vencimiento</th>
            <th>Estado del Stock</th>

        </tr>

        <?php while ($producto = $resultado->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $producto['codigo']; ?>
            </td>

            <td>
                <?php echo $producto['nombre_producto']; ?>
            </td>

            <td>
                <?php echo $producto['nombre_categoria']; ?>
            </td>

            <td>
                <?php echo $producto['stock']; ?>
            </td>

            <td>
                <?php echo $producto['stock_minimo']; ?>
            </td>

            <td>
                S/ <?php echo $producto['precio_venta']; ?>
            </td>

            <td>
                <?php echo $producto['fecha_vencimiento']; ?>
            </td>

            <td>

                <?php

                if ($producto['stock'] == 0) {

                    echo "❌ AGOTADO";

                } elseif (
                    $producto['stock']
                    <=
                    $producto['stock_minimo']
                ) {

                    echo "⚠️ STOCK BAJO";

                } else {

                    echo "✅ DISPONIBLE";

                }

                ?>

            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>