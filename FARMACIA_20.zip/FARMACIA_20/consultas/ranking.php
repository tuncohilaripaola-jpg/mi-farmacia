<?php

include("../seguridad.php");

include("../roles.php");

?>

<?php

include("../conexion.php");

$sql = "SELECT
            p.nombre_producto,
            p.codigo,
            SUM(dv.cantidad) AS total_vendido,
            SUM(dv.importe) AS ingresos_generados
        FROM detalle_ventas dv
        INNER JOIN productos p
            ON dv.idproducto = p.idproducto
        GROUP BY
            p.idproducto,
            p.nombre_producto,
            p.codigo
        ORDER BY total_vendido DESC";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Ranking de Ventas</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>🏆 Ranking de Ventas</h1>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>Posición</th>
            <th>Código</th>
            <th>Producto</th>
            <th>Total Vendido</th>
            <th>Ingresos Generados</th>

        </tr>

        <?php

        $posicion = 1;

        while ($producto = $resultado->fetch_assoc()) {

        ?>

        <tr>

            <td>

                <?php

                if ($posicion == 1) {

                    echo "🥇 1";

                } elseif ($posicion == 2) {

                    echo "🥈 2";

                } elseif ($posicion == 3) {

                    echo "🥉 3";

                } else {

                    echo $posicion;

                }

                ?>

            </td>

            <td>

                <?php echo $producto['codigo']; ?>

            </td>

            <td>

                <?php echo $producto['nombre_producto']; ?>

            </td>

            <td>

                <?php echo $producto['total_vendido']; ?>

            </td>

            <td>

                S/

                <?php echo $producto['ingresos_generados']; ?>

            </td>

        </tr>

        <?php

            $posicion++;

        }

        ?>

    </table>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>