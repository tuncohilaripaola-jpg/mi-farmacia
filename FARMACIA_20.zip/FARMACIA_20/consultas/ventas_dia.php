<?php

include("../seguridad.php");

include("../roles.php");


?>
<?php

include("../conexion.php");

$sql = "SELECT
            v.idventa,
            v.fecha,
            CONCAT(c.nombres, ' ', c.apellidos) AS cliente,
            u.usuario,
            cv.nombre_condicion,
            v.subtotal,
            v.igv,
            v.total
        FROM ventas v
        INNER JOIN clientes c
            ON v.idcliente = c.idcliente
        INNER JOIN usuarios u
            ON v.idusuario = u.idusuario
        INNER JOIN condiciones_venta cv
            ON v.idcondicion = cv.idcondicion
        WHERE DATE(v.fecha) = CURDATE()
        ORDER BY v.fecha DESC";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Ventas del Día</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>📅 Ventas del Día</h1>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>ID Venta</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Vendedor</th>
            <th>Condición</th>
            <th>Subtotal</th>
            <th>IGV</th>
            <th>Total</th>

        </tr>

        <?php while ($venta = $resultado->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $venta['idventa']; ?>
            </td>

            <td>
                <?php echo $venta['fecha']; ?>
            </td>

            <td>
                <?php echo $venta['cliente']; ?>
            </td>

            <td>
                <?php echo $venta['usuario']; ?>
            </td>

            <td>
                <?php echo $venta['nombre_condicion']; ?>
            </td>

            <td>
                S/ <?php echo $venta['subtotal']; ?>
            </td>

            <td>
                S/ <?php echo $venta['igv']; ?>
            </td>

            <td>
                <strong>
                    S/ <?php echo $venta['total']; ?>
                </strong>
            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>