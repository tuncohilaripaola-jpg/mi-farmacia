<?php

include("../seguridad.php");
include("../roles.php");
include("../conexion.php");

$fecha_inicio = $_GET['fecha_inicio'] ?? date('Y-m-d');
$fecha_fin = $_GET['fecha_fin'] ?? date('Y-m-d');

$sql = "SELECT
            v.idventa,
            v.fecha,
            CONCAT(c.nombres,' ',c.apellidos) AS cliente,
            u.usuario,
            cv.nombre_condicion,
            v.subtotal,
            v.igv,
            v.total
        FROM ventas v
        INNER JOIN clientes c
            ON v.idcliente = c.idcliente
        INNER JOIN usuarios u
            ON v.idusuario = u.idusuario
        INNER JOIN condiciones_venta cv
            ON v.idcondicion = cv.idcondicion
        WHERE DATE(v.fecha) BETWEEN '$fecha_inicio' AND '$fecha_fin'
        ORDER BY v.fecha DESC";

$resultado = $conexion->query($sql);

$sqlTotal = "SELECT SUM(total) AS totalventas
             FROM ventas
             WHERE DATE(fecha)
             BETWEEN '$fecha_inicio' AND '$fecha_fin'";

$resTotal = $conexion->query($sqlTotal);
$totalGeneral = $resTotal->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<title>Consulta de Ventas por Fecha</title>

<link rel="stylesheet" href="../css/estilos.css">

<style>

table{

width:100%;
border-collapse:collapse;
margin-top:20px;

}

table th{

background:#28a745;
color:white;
padding:10px;

}

table td{

padding:8px;
border:1px solid #ccc;

}

.total{

font-size:20px;
color:#0b7d28;
font-weight:bold;

}

@media print{

button,a{

display:none;

}

}

</style>

</head>

<body>

<div class="contenedor">

<h1>📆 Consulta de Ventas por Fecha</h1>

<form method="GET">

<label>Fecha Inicial</label><br>

<input
type="date"
name="fecha_inicio"
value="<?php echo $fecha_inicio; ?>"
required>

<br><br>

<label>Fecha Final</label><br>

<input
type="date"
name="fecha_fin"
value="<?php echo $fecha_fin; ?>"
required>

<br><br>

<button type="submit">

🔍 Buscar

</button>

</form>

<br>

<p class="total">

Total Vendido:
S/.
<?php
echo number_format($totalGeneral['totalventas'] ?? 0,2);
?>

</p>

<?php

if($resultado->num_rows>0){

?>

<table>

<tr>

<th>ID</th>

<th>Fecha</th>

<th>Cliente</th>

<th>Vendedor</th>

<th>Condición</th>

<th>Subtotal</th>

<th>IGV</th>

<th>Total</th>

</tr>

<?php

while($venta=$resultado->fetch_assoc()){

?>

<tr>

<td><?php echo $venta['idventa']; ?></td>

<td><?php echo date("d/m/Y",strtotime($venta['fecha'])); ?></td>

<td><?php echo $venta['cliente']; ?></td>

<td><?php echo $venta['usuario']; ?></td>

<td><?php echo $venta['nombre_condicion']; ?></td>

<td align="right">

S/.
<?php echo number_format($venta['subtotal'],2); ?>

</td>

<td align="right">

S/.
<?php echo number_format($venta['igv'],2); ?>

</td>

<td align="right">

<strong>

S/.
<?php echo number_format($venta['total'],2); ?>

</strong>

</td>

</tr>

<?php

}

?>

</table>

<?php

}else{

echo "<h3 style='color:red'>
No existen ventas registradas en ese rango de fechas.
</h3>";

}

?>

<br>

<button onclick="window.print()">

🖨 Imprimir Reporte

</button>

&nbsp;

<a href="../index.php">

⬅️ Volver al Menú

</a>

</div>

</body>

</html>

<?php

$conexion->close();

?>