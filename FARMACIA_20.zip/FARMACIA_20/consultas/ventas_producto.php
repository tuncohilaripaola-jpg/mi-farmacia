<?php

include("../seguridad.php");

include("../roles.php");


?>

<?php

include("../conexion.php");

$idproducto = $_GET['idproducto'] ?? "";

$resultado = null;

if ($idproducto != "") {

    $sql = "SELECT
                v.idventa,
                v.fecha,
                CONCAT(c.nombres, ' ', c.apellidos) AS cliente,
                u.usuario,
                p.nombre_producto,
                dv.cantidad,
                dv.precio_unitario,
                dv.importe
            FROM detalle_ventas dv
            INNER JOIN ventas v
                ON dv.idventa = v.idventa
            INNER JOIN clientes c
                ON v.idcliente = c.idcliente
            INNER JOIN usuarios u
                ON v.idusuario = u.idusuario
            INNER JOIN productos p
                ON dv.idproducto = p.idproducto
            WHERE dv.idproducto = $idproducto
            ORDER BY v.fecha DESC";

    $resultado = $conexion->query($sql);

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Ventas por Producto</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>💊 Ventas por Producto</h1>

    <form method="GET">

        <label>Seleccionar Producto:</label>

        <br><br>

        <select name="idproducto" required>

            <option value="">Seleccione un producto</option>

            <?php

            $productos = $conexion->query(
                "SELECT * FROM productos
                 WHERE estado = 'A'
                 ORDER BY nombre_producto"
            );

            while ($producto = $productos->fetch_assoc()) {

            ?>

                <option
                    value="<?php echo $producto['idproducto']; ?>"
                    <?php
                    if ($idproducto == $producto['idproducto'])
                        echo "selected";
                    ?>
                >

                    <?php

                    echo $producto['nombre_producto']
                         . " - "
                         . $producto['codigo'];

                    ?>

                </option>

            <?php } ?>

        </select>

        <br><br>

        <button type="submit">

            🔍 Buscar Ventas

        </button>

    </form>

    <br>

    <?php if ($resultado != null) { ?>

        <table border="1" width="100%" cellpadding="10">

            <tr>

                <th>ID Venta</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Vendedor</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Importe</th>

            </tr>

            <?php while ($venta = $resultado->fetch_assoc()) { ?>

            <tr>

                <td>
                    <?php echo $venta['idventa']; ?>
                </td>

                <td>
                    <?php echo $venta['fecha']; ?>
                </td>

                <td>
                    <?php echo $venta['cliente']; ?>
                </td>

                <td>
                    <?php echo $venta['usuario']; ?>
                </td>

                <td>
                    <?php echo $venta['nombre_producto']; ?>
                </td>

                <td>
                    <?php echo $venta['cantidad']; ?>
                </td>

                <td>
                    S/ <?php echo $venta['precio_unitario']; ?>
                </td>

                <td>
                    S/ <?php echo $venta['importe']; ?>
                </td>

            </tr>

            <?php } ?>

        </table>

    <?php } ?>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>