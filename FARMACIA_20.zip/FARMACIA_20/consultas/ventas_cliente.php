<?php

include("../seguridad.php");

include("../roles.php");


?>

<?php

include("../conexion.php");

$idcliente = $_GET['idcliente'] ?? "";

$resultado = null;

if ($idcliente != "") {

    $sql = "SELECT
                v.idventa,
                v.fecha,
                CONCAT(c.nombres, ' ', c.apellidos) AS cliente,
                u.usuario,
                cv.nombre_condicion,
                v.subtotal,
                v.igv,
                v.total
            FROM ventas v
            INNER JOIN clientes c
                ON v.idcliente = c.idcliente
            INNER JOIN usuarios u
                ON v.idusuario = u.idusuario
            INNER JOIN condiciones_venta cv
                ON v.idcondicion = cv.idcondicion
            WHERE v.idcliente = $idcliente
            ORDER BY v.fecha DESC";

    $resultado = $conexion->query($sql);

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Ventas por Cliente</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>👥 Ventas por Cliente</h1>

    <form method="GET">

        <label>Seleccionar Cliente:</label>

        <br><br>

        <select name="idcliente" required>

            <option value="">Seleccione un cliente</option>

            <?php

            $clientes = $conexion->query(
                "SELECT * FROM clientes
                 WHERE estado = 'A'
                 ORDER BY nombres"
            );

            while ($cliente = $clientes->fetch_assoc()) {

            ?>

                <option
                    value="<?php echo $cliente['idcliente']; ?>"
                    <?php
                    if ($idcliente == $cliente['idcliente'])
                        echo "selected";
                    ?>
                >

                    <?php

                    echo $cliente['nombres']
                         . " "
                         . $cliente['apellidos'];

                    ?>

                </option>

            <?php } ?>

        </select>

        <br><br>

        <button type="submit">

            🔍 Buscar Ventas

        </button>

    </form>

    <br>

    <?php if ($resultado != null) { ?>

        <table border="1" width="100%" cellpadding="10">

            <tr>

                <th>ID Venta</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Vendedor</th>
                <th>Condición</th>
                <th>Subtotal</th>
                <th>IGV</th>
                <th>Total</th>

            </tr>

            <?php while ($venta = $resultado->fetch_assoc()) { ?>

            <tr>

                <td>
                    <?php echo $venta['idventa']; ?>
                </td>

                <td>
                    <?php echo $venta['fecha']; ?>
                </td>

                <td>
                    <?php echo $venta['cliente']; ?>
                </td>

                <td>
                    <?php echo $venta['usuario']; ?>
                </td>

                <td>
                    <?php echo $venta['nombre_condicion']; ?>
                </td>

                <td>
                    S/ <?php echo $venta['subtotal']; ?>
                </td>

                <td>
                    S/ <?php echo $venta['igv']; ?>
                </td>

                <td>

                    <strong>

                        S/ <?php echo $venta['total']; ?>

                    </strong>

                </td>

            </tr>

            <?php } ?>

        </table>

    <?php } ?>

    <br>

    <a href="../index.php">

        ⬅️ Volver al menú

    </a>

</div>

</body>

</html>