<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $dni = $_POST['dni'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $direccion = $_POST['direccion'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO clientes
            (dni, nombres, apellidos, telefono, email, direccion, estado)
            VALUES
            ('$dni', '$nombres', '$apellidos', '$telefono', '$email', '$direccion', '$estado')";

    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");
        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Agregar Cliente</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>➕ Agregar Cliente</h1>

    <form method="POST">

        <label>DNI:</label>
        <br>

        <input type="text" name="dni" maxlength="8" required>

        <br><br>

        <label>Nombres:</label>
        <br>

        <input type="text" name="nombres" required>

        <br><br>

        <label>Apellidos:</label>
        <br>

        <input type="text" name="apellidos" required>

        <br><br>

        <label>Teléfono:</label>
        <br>

        <input type="text" name="telefono">

        <br><br>

        <label>Email:</label>
        <br>

        <input type="email" name="email">

        <br><br>

        <label>Dirección:</label>
        <br>

        <input type="text" name="direccion">

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A">ACTIVO</option>

            <option value="I">INACTIVO</option>

        </select>

        <br><br>

        <button type="submit">
            💾 Guardar Cliente
        </button>

    </form>

    <br>

    <a href="listar.php">
        ⬅️ Volver a Clientes
    </a>

</div>

</body>

</html>