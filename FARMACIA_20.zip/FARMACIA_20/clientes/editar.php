<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>


<?php

include("../conexion.php");

$id = $_GET['id'];

$sql = "SELECT * FROM clientes WHERE idcliente = $id";

$resultado = $conexion->query($sql);

$cliente = $resultado->fetch_assoc();


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $dni = $_POST['dni'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    $direccion = $_POST['direccion'];
    $estado = $_POST['estado'];

    $sql = "UPDATE clientes SET

            dni = '$dni',
            nombres = '$nombres',
            apellidos = '$apellidos',
            telefono = '$telefono',
            email = '$email',
            direccion = '$direccion',
            estado = '$estado'

            WHERE idcliente = $id";


    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Editar Cliente</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>✏️ Editar Cliente</h1>

    <form method="POST">

        <label>DNI:</label>
        <br>

        <input
            type="text"
            name="dni"
            value="<?php echo $cliente['dni']; ?>"
            required
        >

        <br><br>

        <label>Nombres:</label>
        <br>

        <input
            type="text"
            name="nombres"
            value="<?php echo $cliente['nombres']; ?>"
            required
        >

        <br><br>

        <label>Apellidos:</label>
        <br>

        <input
            type="text"
            name="apellidos"
            value="<?php echo $cliente['apellidos']; ?>"
            required
        >

        <br><br>

        <label>Teléfono:</label>
        <br>

        <input
            type="text"
            name="telefono"
            value="<?php echo $cliente['telefono']; ?>"
        >

        <br><br>

        <label>Email:</label>
        <br>

        <input
            type="email"
            name="email"
            value="<?php echo $cliente['email']; ?>"
        >

        <br><br>

        <label>Dirección:</label>
        <br>

        <input
            type="text"
            name="direccion"
            value="<?php echo $cliente['direccion']; ?>"
        >

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A"
                <?php if ($cliente['estado'] == 'A') echo 'selected'; ?>>
                ACTIVO
            </option>

            <option value="I"
                <?php if ($cliente['estado'] == 'I') echo 'selected'; ?>>
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">
            💾 Actualizar Cliente
        </button>

    </form>

    <br>

    <a href="listar.php">
        ⬅️ Volver a Clientes
    </a>

</div>

</body>

</html>