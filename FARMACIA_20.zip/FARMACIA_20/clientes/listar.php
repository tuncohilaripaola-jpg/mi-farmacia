<?php

include("../seguridad.php");

include("../roles.php");

?>


<?php

include("../conexion.php");

$sql = "SELECT * FROM clientes";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Clientes - Farmacia 20</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>👥 Lista de Clientes</h1>

    <a href="agregar.php">
        ➕ Agregar Cliente
    </a>

    <br><br>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>ID</th>
            <th>DNI</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Dirección</th>
            <th>Estado</th>
            <th>Acciones</th>

        </tr>

        <?php while ($cliente = $resultado->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $cliente['idcliente']; ?>
            </td>

            <td>
                <?php echo $cliente['dni']; ?>
            </td>

            <td>
                <?php echo $cliente['nombres']; ?>
            </td>

            <td>
                <?php echo $cliente['apellidos']; ?>
            </td>

            <td>
                <?php echo $cliente['telefono']; ?>
            </td>

            <td>
                <?php echo $cliente['email']; ?>
            </td>

            <td>
                <?php echo $cliente['direccion']; ?>
            </td>

            <td>
                <?php echo $cliente['estado']; ?>
            </td>

            <td>

                <a href="editar.php?id=<?php echo $cliente['idcliente']; ?>">
                    ✏️ Editar
                </a>

                |

                <a
                    href="eliminar.php?id=<?php echo $cliente['idcliente']; ?>"
                    onclick="return confirm('¿Deseas eliminar este cliente?')"
                >
                    🗑️ Eliminar
                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">
        ⬅️ Volver al menú
    </a>

</div>

</body>

</html>