<?php

include("../seguridad.php");

?>


<?php

include("../conexion.php");

$id = $_GET['id'];

$sql = "DELETE FROM productos
        WHERE idproducto = $id";

if ($conexion->query($sql) === TRUE) {

    header("Location: listar.php");

    exit();

} else {

    echo "Error al eliminar: " . $conexion->error;

}

?>