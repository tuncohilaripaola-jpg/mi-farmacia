<?php
session_start();

include("../seguridad.php");
include("../conexion.php");

if (!isset($_GET["id"])) {
    die("Producto no encontrado.");
}

$id = intval($_GET["id"]);

$stmt = $conexion->prepare("
SELECT
p.*,
c.nombre_categoria,
pr.nombre AS proveedor

FROM productos p

INNER JOIN categorias c
ON p.idcategoria=c.idcategoria

INNER JOIN proveedores pr
ON p.idproveedor=pr.idproveedor

WHERE p.idproducto=?
");

$stmt->bind_param("i",$id);

$stmt->execute();

$producto=$stmt->get_result()->fetch_assoc();

if(!$producto){

    die("Producto no existe.");

}

?>

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<title>Ver Producto</title>

<link rel="stylesheet" href="../css/estilos.css">

<style>

body{

font-family:Arial;

background:#f4f4f4;

}

.contenedor{

width:800px;

margin:30px auto;

background:#fff;

padding:20px;

border-radius:10px;

box-shadow:0 0 10px rgba(0,0,0,.2);

}

table{

width:100%;

border-collapse:collapse;

margin-top:20px;

}

td{

padding:10px;

border:1px solid #ddd;

}

.titulo{

background:#28a745;

color:white;

font-weight:bold;

width:250px;

}

</style>

</head>

<body>

<div class="contenedor">

<h2>Información del Producto</h2>

<table>

<tr>

<td class="titulo">Código</td>

<td><?php echo $producto["codigo"]; ?></td>

</tr>

<tr>

<td class="titulo">Nombre</td>

<td><?php echo $producto["nombre_producto"]; ?></td>

</tr>

<tr>

<td class="titulo">Principio Activo</td>

<td><?php echo $producto["principio_activo"]; ?></td>

</tr>

<tr>

<td class="titulo">Presentación</td>

<td><?php echo $producto["presentacion"]; ?></td>

</tr>

<tr>

<td class="titulo">Concentración</td>

<td><?php echo $producto["concentracion"]; ?></td>

</tr>