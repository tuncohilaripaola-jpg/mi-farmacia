<?php

include("../seguridad.php");

?>

<?php

include("../conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $codigo = $_POST['codigo'];
    $nombre_producto = $_POST['nombre_producto'];
    $principio_activo = $_POST['principio_activo'];
    $presentacion = $_POST['presentacion'];
    $concentracion = $_POST['concentracion'];
    $idcategoria = $_POST['idcategoria'];
    $idproveedor = $_POST['idproveedor'];
    $stock = $_POST['stock'];
    $stock_minimo = $_POST['stock_minimo'];
    $precio_compra = $_POST['precio_compra'];
    $precio_venta = $_POST['precio_venta'];
    $fecha_vencimiento = $_POST['fecha_vencimiento'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO productos
            (
                codigo,
                nombre_producto,
                principio_activo,
                presentacion,
                concentracion,
                idcategoria,
                idproveedor,
                stock,
                stock_minimo,
                precio_compra,
                precio_venta,
                fecha_vencimiento,
                estado
            )
            VALUES
            (
                '$codigo',
                '$nombre_producto',
                '$principio_activo',
                '$presentacion',
                '$concentracion',
                '$idcategoria',
                '$idproveedor',
                '$stock',
                '$stock_minimo',
                '$precio_compra',
                '$precio_venta',
                '$fecha_vencimiento',
                '$estado'
            )";

    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");
        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Agregar Producto</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>➕ Agregar Producto</h1>

    <form method="POST">

        <label>Código:</label>
        <br>

        <input type="text" name="codigo" required>

        <br><br>

        <label>Nombre del Producto:</label>
        <br>

        <input type="text" name="nombre_producto" required>

        <br><br>

        <label>Principio Activo:</label>
        <br>

        <input type="text" name="principio_activo">

        <br><br>

        <label>Presentación:</label>
        <br>

        <input type="text" name="presentacion">

        <br><br>

        <label>Concentración:</label>
        <br>

        <input type="text" name="concentracion">

        <br><br>

        <label>Categoría:</label>
        <br>

        <select name="idcategoria" required>

            <?php

            $categorias = $conexion->query(
                "SELECT * FROM categorias WHERE estado = 'A'"
            );

            while ($categoria = $categorias->fetch_assoc()) {

            ?>

                <option value="<?php echo $categoria['idcategoria']; ?>">

                    <?php echo $categoria['nombre_categoria']; ?>

                </option>

            <?php } ?>

        </select>

        <br><br>

        <label>Proveedor:</label>
        <br>

        <select name="idproveedor" required>

            <?php

            $proveedores = $conexion->query(
                "SELECT * FROM proveedores WHERE estado = 'A'"
            );

            while ($proveedor = $proveedores->fetch_assoc()) {

            ?>

                <option value="<?php echo $proveedor['idproveedor']; ?>">

                    <?php echo $proveedor['nombre_proveedor']; ?>

                </option>

            <?php } ?>

        </select>

        <br><br>

        <label>Stock:</label>
        <br>

        <input type="number" name="stock" min="0" required>

        <br><br>

        <label>Stock Mínimo:</label>
        <br>

        <input type="number" name="stock_minimo" min="0" required>

        <br><br>

        <label>Precio de Compra:</label>
        <br>

        <input type="number" step="0.01" name="precio_compra" min="0" required>

        <br><br>

        <label>Precio de Venta:</label>
        <br>

        <input type="number" step="0.01" name="precio_venta" min="0" required>

        <br><br>

        <label>Fecha de Vencimiento:</label>
        <br>

        <input type="date" name="fecha_vencimiento">

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A">ACTIVO</option>

            <option value="I">INACTIVO</option>

        </select>

        <br><br>

        <button type="submit">

            💾 Guardar Producto

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Productos

    </a>

</div>

</body>

</html>