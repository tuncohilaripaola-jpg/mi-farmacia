<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$sql = "SELECT 
            p.idproducto,
            p.codigo,
            p.nombre_producto,
            p.principio_activo,
            p.presentacion,
            p.concentracion,
            c.nombre_categoria,
            pr.nombre_proveedor,
            p.stock,
            p.stock_minimo,
            p.precio_compra,
            p.precio_venta,
            p.fecha_vencimiento,
            p.estado
        FROM productos p
        INNER JOIN categorias c
            ON p.idcategoria = c.idcategoria
        INNER JOIN proveedores pr
            ON p.idproveedor = pr.idproveedor";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Productos - Farmacia 20</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>💊 Lista de Productos</h1>

    <a href="agregar.php">
        ➕ Agregar Producto
    </a>

    <br><br>

    <table border="1" width="100%" cellpadding="8">

        <tr>

            <th>ID</th>
            <th>Código</th>
            <th>Producto</th>
            <th>Principio Activo</th>
            <th>Presentación</th>
            <th>Concentración</th>
            <th>Categoría</th>
            <th>Proveedor</th>
            <th>Stock</th>
            <th>Precio Venta</th>
            <th>Vencimiento</th>
            <th>Estado</th>
            <th>Acciones</th>

        </tr>

        <?php while ($producto = $resultado->fetch_assoc()) { ?>

        <tr>

            <td><?php echo $producto['idproducto']; ?></td>

            <td><?php echo $producto['codigo']; ?></td>

            <td><?php echo $producto['nombre_producto']; ?></td>

            <td><?php echo $producto['principio_activo']; ?></td>

            <td><?php echo $producto['presentacion']; ?></td>

            <td><?php echo $producto['concentracion']; ?></td>

            <td><?php echo $producto['nombre_categoria']; ?></td>

            <td><?php echo $producto['nombre_proveedor']; ?></td>

            <td><?php echo $producto['stock']; ?></td>

            <td>S/ <?php echo $producto['precio_venta']; ?></td>

            <td><?php echo $producto['fecha_vencimiento']; ?></td>

            <td><?php echo $producto['estado']; ?></td>

            <td>

                <a href="editar.php?id=<?php echo $producto['idproducto']; ?>">
                    ✏️ Editar
                </a>

                |

                <a
                    href="eliminar.php?id=<?php echo $producto['idproducto']; ?>"
                    onclick="return confirm('¿Deseas eliminar este producto?')"
                >
                    🗑️ Eliminar
                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">
        ⬅️ Volver al menú
    </a>

</div>

</body>

</html>