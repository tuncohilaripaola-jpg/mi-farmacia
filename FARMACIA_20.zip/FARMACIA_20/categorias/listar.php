<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$sql = "SELECT * FROM categorias";

$resultado = $conexion->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Categorías - Farmacia 20</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>🗂️ Lista de Categorías</h1>

    <a href="agregar.php">
        ➕ Agregar Categoría
    </a>

    <br><br>

    <table border="1" width="100%" cellpadding="10">

        <tr>

            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Estado</th>
            <th>Acciones</th>

        </tr>

        <?php while ($categoria = $resultado->fetch_assoc()) { ?>

        <tr>

            <td>
                <?php echo $categoria['idcategoria']; ?>
            </td>

            <td>
                <?php echo $categoria['nombre_categoria']; ?>
            </td>

            <td>
                <?php echo $categoria['descripcion']; ?>
            </td>

            <td>
                <?php echo $categoria['estado']; ?>
            </td>

            <td>

                <a href="editar.php?id=<?php echo $categoria['idcategoria']; ?>">
                    ✏️ Editar
                </a>

                |

                <a
                    href="eliminar.php?id=<?php echo $categoria['idcategoria']; ?>"
                    onclick="return confirm('¿Deseas eliminar esta categoría?')"
                >
                    🗑️ Eliminar
                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

    <br>

    <a href="../index.php">
        ⬅️ Volver al menú
    </a>

</div>

</body>

</html>