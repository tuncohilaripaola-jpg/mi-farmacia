<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

$id = $_GET['id'];

$sql = "SELECT * FROM categorias
        WHERE idcategoria = $id";

$resultado = $conexion->query($sql);

$categoria = $resultado->fetch_assoc();


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre_categoria = $_POST['nombre_categoria'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];

    $sql = "UPDATE categorias SET

            nombre_categoria = '$nombre_categoria',
            descripcion = '$descripcion',
            estado = '$estado'

            WHERE idcategoria = $id";


    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Editar Categoría</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>✏️ Editar Categoría</h1>

    <form method="POST">

        <label>Nombre de la Categoría:</label>
        <br>

        <input
            type="text"
            name="nombre_categoria"
            value="<?php echo $categoria['nombre_categoria']; ?>"
            required
        >

        <br><br>

        <label>Descripción:</label>
        <br>

        <textarea
            name="descripcion"
            rows="4"
            cols="50"
        ><?php echo $categoria['descripcion']; ?></textarea>

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option
                value="A"
                <?php
                if ($categoria['estado'] == 'A')
                    echo "selected";
                ?>
            >
                ACTIVO
            </option>

            <option
                value="I"
                <?php
                if ($categoria['estado'] == 'I')
                    echo "selected";
                ?>
            >
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">

            💾 Actualizar Categoría

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Categorías

    </a>

</div>

</body>

</html>