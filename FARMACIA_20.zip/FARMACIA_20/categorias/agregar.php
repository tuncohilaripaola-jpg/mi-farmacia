<?php

include("../seguridad.php");

include("../roles.php");

soloAdministrador();

?>

<?php

include("../conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre_categoria = $_POST['nombre_categoria'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO categorias
            (
                nombre_categoria,
                descripcion,
                estado
            )
            VALUES
            (
                '$nombre_categoria',
                '$descripcion',
                '$estado'
            )";

    if ($conexion->query($sql) === TRUE) {

        header("Location: listar.php");

        exit();

    } else {

        echo "Error: " . $conexion->error;

    }

}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <title>Agregar Categoría</title>

    <link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

    <h1>➕ Agregar Categoría</h1>

    <form method="POST">

        <label>Nombre de la Categoría:</label>
        <br>

        <input
            type="text"
            name="nombre_categoria"
            required
        >

        <br><br>

        <label>Descripción:</label>
        <br>

        <textarea
            name="descripcion"
            rows="4"
            cols="50"
        ></textarea>

        <br><br>

        <label>Estado:</label>
        <br>

        <select name="estado">

            <option value="A">
                ACTIVO
            </option>

            <option value="I">
                INACTIVO
            </option>

        </select>

        <br><br>

        <button type="submit">

            💾 Guardar Categoría

        </button>

    </form>

    <br>

    <a href="listar.php">

        ⬅️ Volver a Categorías

    </a>

</div>

</body>

</html>