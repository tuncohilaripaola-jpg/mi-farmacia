<?php

session_start();

if (!isset($_SESSION['idusuario'])) {

    header("Location: /FARMACIA_20/login.php");

    exit();

}

?>